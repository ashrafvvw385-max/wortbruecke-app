import "./style.css";
import { dictionary } from "./dictionary.js";
import * as pdfjsLib from "pdfjs-dist";
import pdfWorker from "pdfjs-dist/build/pdf.worker.min.mjs?url";

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorker;
const $ = (s) => document.querySelector(s);
const state = loadState();
function loadState() {
  try { return {correct:0,total:0,favorites:[],...(JSON.parse(localStorage.getItem("wortbruecke-state")||"{}"))}; }
  catch { return {correct:0,total:0,favorites:[]}; }
}
function saveState(){ localStorage.setItem("wortbruecke-state",JSON.stringify(state)); renderStats(); }
function safeText(value){ return String(value ?? ""); }
function renderWords(query="") {
  const q=query.trim().toLocaleLowerCase();
  const found=dictionary.filter(w=>[w.word,w.ar,w.article,w.example].some(v=>safeText(v).toLocaleLowerCase().includes(q)));
  $("#word-count").textContent=`${found.length} كلمة`;
  const list=$("#word-list"); list.replaceChildren();
  if(!found.length){const p=document.createElement("p");p.className="empty";p.textContent="لم نعثر على كلمة مطابقة.";list.append(p);return;}
  found.forEach(w=>{
    const card=document.createElement("article");card.className="word-card";
    const main=document.createElement("div");main.className="word-main";
    const word=document.createElement("div");word.className="german";
    if(w.article){const art=document.createElement("span");art.className="article";art.textContent=w.article;word.append(art);}
    word.append(document.createTextNode(" "+w.word));
    const trans=document.createElement("div");trans.className="translation";trans.textContent=w.ar;
    main.append(word,trans);
    if(w.plural && w.plural!=="—"){const pl=document.createElement("div");pl.className="example";pl.textContent=`الجمع: ${w.plural}`;main.append(pl);}
    const ex=document.createElement("div");ex.className="example";ex.textContent=`${w.example} — ${w.exampleAr}`;main.append(ex);
    const fav=document.createElement("button");fav.className="favorite"+(state.favorites.includes(w.id)?" on":"");fav.type="button";fav.textContent=state.favorites.includes(w.id)?"★":"☆";fav.setAttribute("aria-label","إضافة إلى المفضلة");
    fav.addEventListener("click",()=>{state.favorites=state.favorites.includes(w.id)?state.favorites.filter(id=>id!==w.id):[...state.favorites,w.id];saveState();renderWords($("#search").value);});
    card.append(main,fav);list.append(card);
  });
}
$("#search").addEventListener("input",e=>renderWords(e.target.value));
document.querySelectorAll(".tab").forEach(btn=>btn.addEventListener("click",()=>{
  document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b===btn));
  document.querySelectorAll(".page").forEach(p=>p.classList.toggle("active",p.id===btn.dataset.page));
  if(btn.dataset.page==="progress")renderStats();
}));
let current=null,answered=false;
function newQuestion(){
  current=dictionary[Math.floor(Math.random()*dictionary.length)];answered=false;
  $("#quiz-word").textContent=current.word;$("#quiz-feedback").textContent="";
  const options=new Set([current.ar]);
  while(options.size<Math.min(4,dictionary.length)){options.add(dictionary[Math.floor(Math.random()*dictionary.length)].ar);}
  const shuffled=[...options].sort(()=>Math.random()-.5);const root=$("#quiz-options");root.replaceChildren();
  shuffled.forEach(answer=>{const b=document.createElement("button");b.className="option";b.textContent=answer;b.addEventListener("click",()=>{
    if(answered)return;answered=true;state.total++;
    if(answer===current.ar){state.correct++;b.classList.add("correct");$("#quiz-feedback").textContent="إجابة صحيحة! أحسنت."; }
    else{b.classList.add("wrong");$("#quiz-feedback").textContent=`الإجابة الصحيحة: ${current.ar}`;[...root.children].forEach(opt=>{if(opt.textContent===current.ar)opt.classList.add("correct");});}
    [...root.children].forEach(opt=>opt.disabled=true);saveState();
  });root.append(b);});
}
$("#next-question").addEventListener("click",newQuestion);
$("#pdf-file").addEventListener("change",async e=>{
  const file=e.target.files?.[0];if(!file)return;
  $("#pdf-text").value="";$("#pdf-status").textContent="جارٍ قراءة الملف…";
  try{
    if(file.type && file.type!=="application/pdf" && !file.name.toLowerCase().endsWith(".pdf"))throw new Error("الملف المحدد ليس PDF.");
    if(file.size>30*1024*1024)throw new Error("حجم الملف أكبر من 30 ميغابايت.");
    const bytes=new Uint8Array(await file.arrayBuffer());
    const pdf=await pdfjsLib.getDocument({data:bytes}).promise;
    const pages=[];
    for(let i=1;i<=pdf.numPages;i++){
      const page=await pdf.getPage(i);const content=await page.getTextContent();
      pages.push(content.items.map(item=>("str" in item?item.str:"")).join(" "));
    }
    const text=pages.join("\n\n");
    if(!text.trim())throw new Error("لم يُعثر على نص قابل للاستخراج. قد يكون الملف ممسوحًا كصور ويحتاج إلى OCR.");
    $("#pdf-text").value=text;$("#pdf-status").textContent=`تم استخراج النص من ${pdf.numPages} صفحة.`;
  }catch(err){$("#pdf-status").textContent=`تعذر قراءة الملف: ${err?.message||"خطأ غير معروف"}`;}
});
$("#copy-pdf").addEventListener("click",async()=>{
  const text=$("#pdf-text").value;if(!text){$("#pdf-status").textContent="لا يوجد نص لنسخه.";return;}
  try{await navigator.clipboard.writeText(text);$("#pdf-status").textContent="تم نسخ النص.";}
  catch{$("#pdf-text").focus();$("#pdf-text").select();$("#pdf-status").textContent="حدد النص وانسخه يدويًا.";}
});
function renderStats(){$("#correct-stat").textContent=state.correct;$("#total-stat").textContent=state.total;$("#fav-stat").textContent=state.favorites.length;}
$("#reset-progress").addEventListener("click",()=>{if(confirm("هل تريد حذف التقدم والكلمات المفضلة؟")){state.correct=0;state.total=0;state.favorites=[];saveState();renderWords($("#search").value);}});
renderWords();renderStats();newQuestion();

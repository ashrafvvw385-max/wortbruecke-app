# WortBruecke Android starter

مشروع ابتدائي لتطبيق قاموس ألماني–عربي يعمل محليًا مع اختبار مفردات وقارئ PDF نصي.

## المتطلبات
- Node.js 22
- npm
- Android Studio + JDK 21 لبناء Android محليًا
- اتصال إنترنت أول مرة لتنزيل حزم npm ومكونات Gradle. بعد تثبيت الموارد داخل APK تعمل الوظائف المضمنة دون إنترنت.

## التشغيل على الكمبيوتر
```bash
npm install
npm run dev
```

## بناء ملفات الويب
```bash
npm run build
```

## إنشاء مشروع Android لأول مرة
```bash
npx cap add android
npx cap sync android
npx cap open android
```
بعدها افتح المشروع في Android Studio، وانتظر اكتمال Gradle Sync، ثم اختر Build > Build APK(s).

## بناء APK من GitHub Actions
1. ارفع ملفات المشروع إلى مستودع GitHub.
2. افتح تبويب Actions وفعّل Actions إن طلب GitHub ذلك.
3. شغّل `Build Android APK` عبر Run workflow، أو ادفع تحديثًا إلى فرع `main` أو `master`.
4. بعد نجاح العملية افتح نتيجة التشغيل (workflow run)، ثم نزّل Artifact باسم `WortBruecke-debug-apk`.
5. فك ZIP وستجد `app-debug.apk`. هذا إصدار Debug للتجربة، وليس إصدار نشر موقّعًا للمتجر.

## ملاحظات مهمة
- `src/dictionary.js` يحتوي 30 مدخلًا تجريبيًا فقط. راجع الترجمة والجمع وأضف بيانات موثوقة قبل الاعتماد عليه كقاموس شامل.
- قارئ PDF يستخرج النص المضمن في PDF. لا يحتوي المشروع على OCR للملفات الممسوحة ضوئيًا كصور.
- التقدم والمفضلة يُحفظان باستخدام localStorage على الجهاز نفسه.
- لا توجد مزامنة سحابية أو حسابات مستخدمين في هذا النموذج الأولي.
- تم إعداد سير عمل بناء آلي، لكن نجاح البناء يجب تأكيده من نتيجة GitHub Actions الفعلية.
- لا تعتمد على خطوط Google الخارجية عند العمل دون اتصال؛ أزل استيراد Google Fonts من `src/style.css` أو ضمّن ملفات الخطوط محليًا إذا أردت تضمين الخطوط بالكامل.
